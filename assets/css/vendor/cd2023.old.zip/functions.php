<?php

use noleam\Theme;

require(__DIR__ . '/classes/noleam/Theme.php');

Theme::instance()->init([
        'styles' => [
            [
                'handle' => 'choices',
                'file' => 'vendor/choices.min.css'],
            [
                'handle' => 'cd2023',
                'file' => 'style.css', 'deps' => ['choices']],
        ],

        'scripts' => [
            'noleam' => [
                'type' => 'module',
                'handle' => 'noleam',
                'file' => 'noleam.js',
                'deps' => ['choices']
            ],
            'choices' => [
                'handle' => 'choices',
                'file' => 'vendor/choices/choices.min.js',
            ],
        ],
        'add_theme_support' => ['wp-block-styles', 'align-wide', 'block-template-parts', 'block-template'],
        'add_editor_style' => ['./assets/css/style.css'],
    ]
);
