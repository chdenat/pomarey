<?php
/*******************************************************************************
 * Title: Séparation texte 2 colonnes
 *
 * Slug: noleam/pretty-text-2-columns
 *
 * Categories: noleam
 ******************************************************************************/
?>


<!-- wp:group {"backgroundColor":"secondary","className":"text-2-columns","layout":{"type":"constrained"}} -->
<div class="wp-block-group text-2-columns has-secondary-background-color has-background">
    <!-- wp:columns {"style":{"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"},"margin":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}}} -->
    <div class="wp-block-columns"
         style="margin-top:var(--wp--preset--spacing--70);margin-bottom:var(--wp--preset--spacing--70);padding-top:0;padding-right:0;padding-bottom:0;padding-left:0">
        <!-- wp:column {"style":{"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"}},"border":{"right":{"color":"var:preset|color|primary","width":"1px"},"bottom":{"color":"var:preset|color|primary","width":"1px"}}}} -->
        <div class="wp-block-column"
             style="border-right-color:var(--wp--preset--color--primary);border-right-width:1px;border-bottom-color:var(--wp--preset--color--primary);border-bottom-width:1px;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0">
            <!-- wp:paragraph {"align":"center","style":{"typography":{"fontStyle":"normal","fontWeight":"300","lineHeight":"1.5"},"spacing":{"padding":{"top":"var:preset|spacing|70","right":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|70"}}},"fontSize":"medium","fontFamily":"texte2-font"} -->
            <p class="has-text-align-center has-texte-2-font-font-family has-medium-font-size"
               style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--70);font-style:normal;font-weight:300;line-height:1.5">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent commodo sodales pretium. Praesent
                volutpat mi lorem, in sodales diam molestie eu. Proin consequat consequat lectus, pellentesque imperdiet
                sem interdum at.</p>
            <!-- /wp:paragraph --></div>
        <!-- /wp:column -->

        <!-- wp:column {"style":{"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
        <div class="wp-block-column" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0">
            <!-- wp:paragraph {"align":"center","style":{"typography":{"fontStyle":"normal","fontWeight":"300","lineHeight":"1.5"},"spacing":{"padding":{"top":"var:preset|spacing|70","right":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|70"}}},"fontSize":"medium","fontFamily":"titles-font"} -->
            <p class="has-text-align-center has-titles-font-font-family has-medium-font-size"
               style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--70);font-style:normal;font-weight:300;line-height:1.5">
                Vivamus sit amet elementum arcu. Vestibulum gravida pretium sem in condimentum. Sed eget enim
                ullamcorper, venenatis turpis sed, consectetur est. Vivamus ac magna blandit mi varius
                commodo.&nbsp;</p>
            <!-- /wp:paragraph --></div>
        <!-- /wp:column --></div>
    <!-- /wp:columns --></div>
<!-- /wp:group -->